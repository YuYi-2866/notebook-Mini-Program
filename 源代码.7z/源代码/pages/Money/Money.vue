<template>
	<view>
		<view class="">
			<p style="margin: 10px;font-weight: bold; border-bottom: 5rpx solid #ab0080;padding: 4px;">收支柱形图</p>
			<canvas canvas-id="myid" id="myid" class="charts" @touchstart="touchustart" @touchmove="touchremove"
				@touchend="touchend" />
		</view>
		<view class="">
			<p style="margin: 10px;font-weight: bold;border-bottom: 5rpx solid #ab3371;padding: 4px;">收入饼状图</p>
			<canvas canvas-id="myIncomeRing" id="myIncomeRing" class="charts" @touchend="tap" />
		</view>
		<view class="">
			<p style="margin: 10px;font-weight: bold;border-bottom: 5rpx solid #a384ab;padding: 4px;">支出饼状图</p>
			<canvas canvas-id="myExpenseRing" id="myExpenseRing" class="charts" @touchend="tap" />
		</view>

	</view>
</template>

<script>
	import uCharts from '@/uni_modules/qiun-data-charts/js_sdk/u-charts/u-charts.js';
	var uChartsInstance = {};
	export default {
		data() {
			return {
				cWidth: 600,
				cHeight: 500,
				Max: null,
				ChartList: {},
				IncomeRingList: [],
				chartData: {},
				opts: {
					color: ["#1890FF", "#91CB74", "#5effb1", "#FC8452", "#9A60B4", "#FAC858", "#EE6666", "#73CODE",
						"#ea7ccc"
					],
					padding: [5, 5, 5, 5],
					enableScroll: false,
					extra: {
						pie: {
							activeOpacity: 0.5,
							activeRadius: 10,
							offsetAngle: 0,
							labelWidth: 15,
							border: true,
							borderWidth: 3,
							borderColor: "#FFFFFF"
						}
					}
				}
			}
		},
		async onReady() {
			//
			this.cWidth = uni.upx2px(700);
			//
			this.cHeight = uni.upx2px(500);

			uniCloud.callFunction({
				name: "Get_tubiao_Accountdb",
				success: (res) => {
					console.log(res.result)
					this.ChartList = res.result.ChartList
					this.Max = res.result.maxNum
					this.IncomeRingList = res.result.IncomeRingList
					this.ExpenseRingList = res.result.ExpenseRingList
					this.getServerData()
					// console.log(this.ChartList.IncomeArray)
				}
			})
		},

		methods: {
			getServerData() {
				//
				setTimeout(() => {
					let res = {
						categories: this.ChartList.dateArray,
						series: [{
								name: "收入",
								data: this.ChartList.IncomeArray
							},
							{
								name: "支出",
								data: this.ChartList.ExpenseArray
							}
						]
					};
					console.log(res)
					this.drawCharts('myid', res);
					let IncomRing = {
						series: [{
							data: this.IncomeRingList
						}]
					}
					let ExpenseRing = {
						series: [{
							data: this.ExpenseRingList
						}]
					}
					this.drawChartsRing('myIncomeRing', IncomRing);
					this.drawChartsRing('myExpenseRing', ExpenseRing)
				}, 500);
			},
			drawChartsRing(id, data) {
				const ctx = uni.createCanvasContext(id, this);
				uChartsInstance[id] = new uCharts({
					type: "pie",
					context: ctx,
					width: this.cWidth,
					height: this.cHeight,
					series: data.series,
					animation: true,
					background: "#FFFFFF",
					color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
						"#ea7ccc"
					],
					padding: [5, 5, 5, 5],
					enableScroll: false,
					extra: {
						pie: {
							activeOpacity: 0.5,
							activeRadius: 10,
							offsetAngle: 0,
							labelWidth: 15,
							border: true,
							borderWidth: 3,
							borderColor: "#FFFFFF"
						}
					}
				})
			},
			drawCharts(id, data) {
				const ctx = uni.createCanvasContext(id, this);
				uChartsInstance[id] = new uCharts({
					type: "column",
					context: ctx,
					width: this.cWidth,
					height: this.cHeight,
					categories: data.categories,
					series: data.series,
					fontSize: 8,
					xAxis: {
						disableGrid: true,
						fontSize: 10
					},
					yAxis: {
						data: [{
							min: 0,
							// max: this.Max
						}],
						fontSize: 10
					},
					extra: {
						column: {
							type: "group"
						}
					}
				})
			},


			tap(e) {
				uChartsInstance[e.target.id].touchLegend(e);
				uChartsInstance[e.target.id].showToolTip(e);
			},
			touchstart(e) {
				uChartsInstance[e.target.id].scrollStart(e);
			},
			touchmove(e) {
				uChartsInstance[e.target.id].scroll(e);
			},
			touchend(e) {
				uChartsInstance[e.target.id].scrollEnd(e);
				uChartsInstance[e.target.id].touchLegend(e);
				uChartsInstance[e.target.id].showToolTip(e);
			}
		}
	}
</script>

<style>
	page {
		background-color: #F8F8F8;

	}

	.charts {
		width: 750rpx;
		height: 500rpx;
	}

	.charts-box {
		width: 100%;
		height: 300px;
	}
</style>
