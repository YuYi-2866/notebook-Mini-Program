<template>
	<view>
		<view class="AddlistImg" @tap="NavTo">
			<image src="../../static/add.png" ></image>
		</view>

		<!-- Tab栏 -->
		<view class="TabStyle">
			<view class="TabItem" :class="TabActiveIndex==0?'TabItem-Active':'' " @click="TabChoose(0)">
				<text>待办事项</text>
				<view class="TabItem-Line" v-show="TabActiveIndex==0"> </view>
			</view>
			<view class="TabItem" :class="TabActiveIndex==1?'TabItem-done-Active':'' " @click="TabChoose(1)">
				<text>已完成事项</text>
				<view class="TabItem-done-line" v-show="TabActiveIndex==1"></view>
			</view>
		</view>

		<!-- 任务栏 -->
		<checkbox-group name="">
			<view class="ListStyle">
				<label v-for="(item,index) in dataList">
					<view class="List-Item" :class="TabActiveIndex==1?'List-Item-done':''">
						<view class="List-Item-title">
							<checkbox :value="item._id" :checked="item.checked"
								@click="check(item._id,item.checked,index)" />
							<text>{{item.title}}</text>
							<image :src="item.level?'../../static/xingxing.png':'../../static/xingxing1.png'" 
								@click="MarkImport(item._id,item.level,index)" @click.stop.native="()=>{}">
							</image>
						</view>
						<view class="List-Item-data">
							<image src="../../static/date1.png" ></image>
							<text>{{item.deadline}}</text>
							<text style="margin-left: 5px;">{{item.deadtime}}</text>
						</view>
					</view>
				</label>
			</view>
		</checkbox-group>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				TabActiveIndex: 0,
				dataList: []

			}
		},
		onShow() {
			uni.showLoading({

			})
			this.dataList = []
			this.GetList()
		},
		methods: {
			NavTo() {
				uni.navigateTo({
					url: "/pages/addlist/addlist"
				})
			},
			TabChoose(index) {
				this.TabActiveIndex = index
				uni.showLoading({

				})
				this.dataList = []
				this.GetList()
			},
			GetList() {
				let that = this
				let where = {
					"checked": null
				}
				if (this.TabActiveIndex == 0) {
					where.checked = false
				} else {
					where.checked = true
				}
				uniCloud.callFunction({
					name: "GetTodolist_from_db",
					data: where
				}).then(res => {
					uni.hideLoading()
					console.log(res.result.data)
					that.dataList = res.result.data
				}).catch(err => {
					console.log(err)
				})
			},
			MarkImport(id, levelMark, index) {
				let update = {
					"level": !levelMark
				}
				console.log("level")
				this.dataList[index].level = !levelMark
				uniCloud.callFunction({
					name: "updata_todoList_db",
					data: {
						"id": id,
						"update": update
					}
				}).then(res => {
					console.log(res)
				}).catch(err => {
					console.log(err)
				})
			},
			check(id, checkVal, index) {
				let update = {
					"checked": !checkVal
				}
				console.log("check")
				console.log(this.dataList)
				let that = this
				console.log(checkVal)
				that.dataList[index].checked = !checkVal
				uniCloud.callFunction({
					name: "updata_todoList_db",
					data: {
						"id": id,
						"update": update
					}
				}).then(res => {
					console.log(res)
					// this.GetList()
					if (that.TabActiveIndex == 0) {
						that.TabChoose(1)
					} else {
						that.TabChoose(0)
					}
				}).catch(err => {
					console.log(err)
				})
			}
		}
	}
</script>

<style>
	.AddlistImg image {
		width: 38px;
		height: 38px;
	}

	.AddlistImg {
		position: fixed;
		bottom: 100px;
		right: 35px;
	}

	.TabStyle {
		display: flex;
		justify-content: space-evenly;
		margin-top: 25px;
		padding-bottom: 15px;
	}

	.TabItem-Line {
		border: 1px solid #be0003;
		margin-top: 10px;
		width: 80%;
	}

	.TabItem-done-line {
		border: 1px solid #650098;
		margin-top: 10px;
		width: 80%;
	}

	.TabItem {
		display: flex;
		flex-direction: column;
		width: 50%;
		align-items: center;
	}

	.TabItem-Active {
		font-weight: 550;
		color: #be0003;
	}

	.TabItem-done-Active {
		font-weight: 550;
		color: #610096;
	}

	.ListStyle {
		display: flex;
		flex-direction: column;
		align-items: center;
		font-size: 18px;
	}

	.List-Item {
		border: 2px solid #ff9398;
		border-radius: 10px;
		margin: 5px;
		width: 90vw;
		padding: 5px;
	}

	.List-Item-done {
		border: 2px solid #610096;
	}

	.List-Item-title {
		display: flex;
		align-items: center;
	}

	.List-Item-title text {
		flex-grow: 2;
	}

	.List-Item-title image {
		width: 15px;
		height: 15px;
		margin-right: 10px;
	}

	.List-Item-data image {
		width: 10px;
		height: 10px;
	}

	.List-Item-data {
		color: #610096;
		font-size: 6px;
		margin-left: 30px;
	}

	.checkbox {
		transform: scale(0.6);
	}
</style>
