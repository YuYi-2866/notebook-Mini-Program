<template>
	<view>
		<view class="content">
			<view class="Addlistyees">
				<input type="text" placeholder="标题" v-model="todoList.title" />
				<textarea value="" placeholder="内容" v-model="todoList.Content" style="height: 300px;" />
				<view class="Mark">
					<view class="MarkSymbol">
						<picker mode="date" :value="todoList.deadline" @change="bindDateChange">
							<view class="uni-input">
								<image src="../../static/rili.png"></image>
							</view>
						</picker>

						<picker @change="bindPickerChange" :value="todoList.level" :range="array">
							<view class="uni-input">
								<image src="../../static/jingshi.png"></image>
							</view>
						</picker>

						<picker mode="time" :value="todoList.deadtime" start="09:01" end="21:01"
							@change="bindTimeChange">
							<view class="uni-input">
								<image src="../../static/shijian.png"></image>
							</view>
						</picker>
					</view>
					<view class="" @tap="GetTodoList">
						添加
					</view>
				</view>
				<view style="display: flex;justify-content: center;">{{date}} {{array[index]}} {{time}}</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			const currentDate = this.getDate({
				format: true
			})
			const currentTime = this.getTime({
				format: true
			})
			return {
				date: currentDate,
				array: ['一般', '重要'],
				time: currentTime,
				index: 0,
				todoList: {
					"title": null,
					"Content": null,
					"deadline": currentDate,
					"level": false,
					// "schedule":0,
					"checked": false,
					"last_modify_date": currentDate,
					"deadtime": currentTime
				}
			}
		},
		methods: {
			GetTodoList() {
				console.log(this.todoList)
				uniCloud.callFunction({
					name: "save_data_todolist",
					data: this.todoList
				}).then(res => {
					console.log(res)
					uni.switchTab({
						url: "/pages/list/list"
					})
				}).catch(err => {
					console.log(err)
				})
			},
			bindPickerChange: function(e) {
				console.log('picker发送选择改变，携带值为', e.detail.value)
				this.index = e.detail.value
				if (e.detail.value == 1) {
					this.todoList.level = true
				}
			},
			bindTimeChange: function(e) {
				this.time = e.detail.value
			},
			bindTimeChange: function(e) {
				this.todoL.time = e.detail.value
			},
			getTime() {
				const date = new Date();
				let hours = date.getHours();
				let minutes = date.getMinutes();
				hours = hours > 9 ? hours : '0' + hours;
				minutes = minutes > 9 ? minutes : '0' + minutes;
				return `${hours}:${minutes}`;
			},
			getDate(type) {
				const date = new Date();
				let year = date.getFullYear();
				let month = date.getMonth() + 1;
				let day = date.getDate();

				if (type === 'start') {
					year = year - 60;
				} else if (type === 'end') {
					year = year + 2;
				}
				month = month > 9 ? month : '0' + month;
				day = day > 9 ? day : '0' + day;
				return `${year}-${month}-${day}`;
			}
		}
	}
</script>

<style>
	page {
		background-color: #feeaff;
	}

	.content {
		display: flex;
		justify-content: space-around;
	}

	.Addlistyees {
		background-color: white;
		padding: 10px;
		width: 80vw;
		margin-top: 15px;
		border-radius: 10px;
	}

	.Addlistyees input,
	textarea {
		border-bottom: 1rpx solid #aa007f;
		padding: 4px;
	}

	.MarkSymbol {
		font-weight: bold;
		display: flex;
	}

	.MarkSymbol image {
		width: 32px;
		height: 32px;
		margin-right: 10px;
	}

	.Mark {
		display: flex;
		padding: 4px;
		justify-content: space-between;
	}
</style>
