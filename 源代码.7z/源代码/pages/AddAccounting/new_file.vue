<template>
</template>

<script>
	export default {
		methods:{
			NumshowClick(item) {
				let str = this.amount.toString();
				if (item.id === "plus" || item.id === "minus") {
					this.decimalClicked = false;
					if (/[-+]/.test(str.charAt(str.length - 1))) {
						this.amount = str.slice(0, -1) + item.show;
					} else {
						this.amount += item.show;
					}
				} else if (item.id === "dot") {
					if (!this.decimalClicked) {
						this.decimalClicked = true;
						this.amount += item.show;
					}
				} else if (item.id === "AC") {
					this.amount = "0";
				} else if (item.id === "numdate") {
					this.Accountdb.Numdate = currentDate;
				} else if (item.id === "back") {
					if (str.length === 2) {
						if (str[0] === '+' || str[0] === '-') {
							this.amount = "0";
						} else {
							this.amount = str.slice(0, -1);
						}
					} else if (str.length === 1) {
						this.amount = "0";
					} else {
						this.amount = str.slice(0, -1);
					}
				} else if (item.id === "enter") {
					let result = eval(str);
					this.amount = result.toString();
					str = "0";
				} else if (item.id === "get") {
					let result = eval(str);
					this.amount = result.toString();
					str = "0";
					this.GetAccountdb();
				} else {
					if (str === "0") {
						if (this.ActiveIndex === 1) {
							this.amount = -item.show;
						} else {
							this.amount = item.show;
						}
					} else {
						this.amount += item.show;
					}
		}
	}
</script>

<style>
</style>