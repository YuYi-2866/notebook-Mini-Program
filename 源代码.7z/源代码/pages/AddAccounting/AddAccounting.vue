<template>
	<view>
		<!-- Tap栏(收入/支出) -->
		<view class="TabStyle">
			<view class="TabItem" v-for="(item,index) in Tabtitle" :class="ActiveIndex==index?'TabItem-Active':'' "
				@click="TapChoose(index)">
				{{item.title}}
			</view>
		</view>
		<!-- 收入途径和支出用途 -->
		<uni-card :is-Shadow="true">
			<text class="cardtitle">{{ActiveIndex==0?'来源':'用途'}}</text>
			<scroll-view scroll-y="true" class="Money-Content-scroll">
				<view class="Money-Content-scroll-content">
					<view class="Money-Content-scroll-row" v-for="(item,index) in UseToicon[ActiveIndex]">
						<view :class="ClickToicon===index ?'Money-Content-scroll-item1':'Money-Content-scroll-item2'"
							@click="MoneyContentClick(item,index)">
							<view class="Money-Content-scroll-item-Img">
								<image :src="item.ImgSrc" mode="scaleToFill"></image>
							</view>
							<view style="margin:2px auto 5px auto;font-weight: bold;">{{item.ImgContent}}</view>
						</view>
					</view>
				</view>
			</scroll-view>
		</uni-card>
		<!-- 计算器及备注 -->
		<uni-card :is-Shadow="true">
			<text class="cardtitle">计算本</text>
			<scroll-view scroll-x="true">
				<view class="computer-show-operation">{{amount}}</view>
			</scroll-view>
			<view class="computer-notes">
				<image src="../../static/orders-fill.png"></image>
				<input type="text" placeholder="点击输入备注" v-model="Accountdb.accountnotes">
			</view>
			<view class="computer-button" v-for="row in computerbotton">
				<view class="computer-button-item" v-for="(item,index) in row">
					<view v-if="item.id==='numdate'">
						<picker mode="date" :value="date" @change="handleChangeDate">
							<view class="uni-input">日程</view>
						</picker>
					</view>
					<view class="datetitle" v-if="item.id==='mountshow'">
						<picker mode="date" :value="date" @change="handleChangeDate">
							<view>{{Accountdb.Numdate.slice(0,4)}}</view>
						</picker>
					</view>
					<view class="datetitle" v-if="item.id==='dayshow'">
						<picker mode="date" :value="date" @change="handleChangeDate">
							<view>{{Accountdb.Numdate.slice(5,11)}}</view>
						</picker>
					</view>
					<view @click="NumshowClick(item)">
						<image :src="item.Img" v-if="item.id==='back'"></image>
						{{item.show}}
					</view>
				</view>
			</view>
		</uni-card>
	</view>
</template>

<script>
	export default {
		data() {
			const currentDate = this.getDate({
				format: true
			})
			return {
				Tabtitle: [{
						title: "收入"
					},
					{
						title: "支出"
					}
				],
				ActiveIndex: 0,
				ClickToicon: null,
				UseToicon: [
					[{
							ImgSrc: "../../static/gongzi.png",
							ImgContent: "工资"
						},
						{
							ImgSrc: "../../static/licai.png",
							ImgContent: "理财"
						}, {
							ImgSrc: "../../static/hongbao.png",
							ImgContent: "红包"
						}, {
							ImgSrc: "../../static/58.png",
							ImgContent: "投资"
						},
						{
							ImgSrc: "../../static/caipiao.png",
							ImgContent: "彩票"
						},
						{
							ImgSrc: "../../static/jiangjin.png",
							ImgContent: "奖金"
						}, {
							ImgSrc: "../../static/money.png",
							ImgContent: "兼职"
						}
					],
					[{
							ImgSrc: "../../static/bookdb.png",
							ImgContent: "书籍"
						},
						{
							ImgSrc: "../../static/birthday.png",
							ImgContent: "零食"
						},
						{
							ImgSrc: "../../static/user-fill.png",
							ImgContent: "社交"
						}, {
							ImgSrc: "../../static/naicha.png",
							ImgContent: "奶茶"
						},
						{
							ImgSrc: "../../static/meishi.png",
							ImgContent: "美食"
						},
						{
							ImgSrc: "../../static/chongwu.png",
							ImgContent: "宠物"
						},
						{
							ImgSrc: "../../static/youxi.png",
							ImgContent: "游戏"
						},
						{
							ImgSrc: "../../static/shuli.png",
							ImgContent: "剪发"
						},
						{
							ImgSrc: "../../static/riyong.png",
							ImgContent: "日用"
						},
						{
							ImgSrc: "../../static/jinian.png",
							ImgContent: "礼物"
						},
						{
							ImgSrc: "../../static/huazhuang.png",
							ImgContent: "化妆"
						},
						{
							ImgSrc: "../../static/yao.png",
							ImgContent: "医疗"
						}
					]
				],
				computerbotton: [
					[{
						id: "numdate",
						show: ""
					}, {
						id: "mountshow",
						show: ""
					}, {
						id: "dayshow",
						show: ""
					}, {
						id: "AC",
						show: "AC"
					}],
					[{
							id: "1",
							show: "1"
						},
						{
							id: "2",
							show: "2"
						},
						{
							id: "3",
							show: "3"
						}, {
							id: "back",
							show: "",
							Img: "../../static/backicon.png"
						}
					],
					[{
							id: "4",
							show: "4"
						},
						{
							id: "5",
							show: "5"
						},
						{
							id: "6",
							show: "6"
						},
						{
							id: "plus",
							show: "+"
						}
					],
					[{
							id: "7",
							show: "7"
						},
						{
							id: "8",
							show: "8"
						},
						{
							id: "9",
							show: "9"
						},
						{
							id: "minus",
							show: "-"
						}
					],
					[{
							id: "dot",
							show: "."
						},
						{
							id: "0",
							show: "0"
						},
						{
							id: "enter",
							show: "="
						},
						{
							id: "get",
							show: "确定"
						}
					]
				],
				amount: "0",
				decimalClicked: false,
				date: currentDate,
				Accountdb: {
					grounp: 0,
					DetailCategory: null,
					DetailCategorylndex: null,
					amountdb: 0,
					accountnotes: null,
					Numdate: currentDate
				}
			}
		},
		methods: {
			TapChoose(index) {
				this.ActiveIndex = index
				this.amount = 0
				this.Accountdb.grounp = index
				this.ClickToicon = null
			},
			MoneyContentClick(item, index) {
				console.log(item, index)
				this.Accountdb.DetailCategory = item.ImgContent
				this.Accountdb.DetailCategorylndex = item.ImgSrc
				this.ClickToicon = index
			},
			handleChangeDate: function(e) {
				this.Accountdb.Numdate = e.detail.value
			},
			getDate(type) {
				const date = new Date();
				let year = date.getFullYear();
				let month = date.getMonth() + 1;
				let day = date.getDate();

				if (type === 'start') {
					year = year - 60;
				} else if (type === 'end') {
					year = year + 2;
				}
				month = month > 9 ? month : '0' + month;
				day = day > 9 ? day : '0' + day;
				return `${year}-${month}-${day}`;
			},
			NumshowClick(item) {
				let str = this.amount.toString();
				if (item.id === "plus" || item.id === "minus") {
					this.decimalClicked = false;
					if (/[-+]/.test(str.charAt(str.length - 1))) {
						this.amount = str.slice(0, -1) + item.show;
					} else {
						this.amount += item.show;
					}
				} else if (item.id === "dot") {
					if (!this.decimalClicked) {
						this.decimalClicked = true;
						this.amount += item.show;
					}
				} else if (item.id === "AC") {
					this.amount = "0";
				} else if (item.id === "numdate") {
					this.Accountdb.Numdate = currentDate;
				} else if (item.id === "back") {
					if (str.length === 2) {
						if (str[0] === '+' || str[0] === '-') {
							this.amount = "0";
						} else {
							this.amount = str.slice(0, -1);
						}
					} else if (str.length === 1) {
						this.amount = "0";
					} else {
						this.amount = str.slice(0, -1);
					}
				} else if (item.id === "enter") {
					let result = eval(str);
					this.amount = result.toString();
					str = "0";
				} else if (item.id === "get") {
					let result = eval(str);
					this.amount = result.toString();
					str = "0";
					this.GetAccountdb();
				} else {
					if (str === "0") {
						if (this.ActiveIndex === 1) {
							this.amount = -item.show;
						} else {
							this.amount = item.show;
						}
					} else {
						this.amount += item.show;
					}
				}
			},
			GetAccountdb() {
				this.Accountdb.amountdb = Number(this.amount)
				console.log(this.Accountdb)
				uniCloud.callFunction({
					name: "SaveAccountTodb",
					data: this.Accountdb
				}).then(res => {
					console.log(res)
					uni.switchTab({
						url: "/pages/account/account"
					})
				}).catch(err => {
					console.log(err)
				})
			}
		}
	}
</script>

<style>
	page {
		background-color: #ffe6f2;
	}

	.TabStyle {
		display: flex;
		justify-content: space-around;
		padding-bottom: 5px;
	}

	.TabItem {
		display: flex;
		flex-direction: column;
		align-items: center;
		border: 1px solid #c34c4d;
		width: 110px;
		height: 28px;
		border-radius: 20px;
		font-size: 18px;
	}

	.TabItem-Active {
		color: white;
		background-color: #c34c4d;
		font-weight: 550;
	}

	.Money-Content-scroll {
		height: 180px;
		margin-top: 10px;
	}

	.Money-Content-scroll-content,
	.computer-button {
		display: flex;
		flex-wrap: wrap;
		width: 280px;
	}

	.Money-Content-scroll-item1,
	.Money-Content-scroll-item2 {
		display: flex;
		flex-direction: column;
		text-align: center;
		align-items: center;
		width: 65px;
		margin: 1.5px 1.5px 5px;
		border-radius: 25px;
	}

	.Money-Content-scroll-item1 {
		background-color: #eed4ff;
	}

	.Money-Content-scroll-item-Img {
		width: 35px;
	}

	.Money-Content-scroll-item-Img image {
		margin-top: 8px;
		height: 30px;
		width: 30px;
	}

	.computer-show-operation {
		margin-top: 10%;
		width: 95%;
		height: 35px;
		text-align: right;
		font-size: 40px;
	}

	.computer-notes {
		display: flex;
		margin: 10px auto 8px;
		border: 1px solid silver;
		width: 95%;
		padding: 2.4%;
		border-radius: 6px;
		align-items: center;
	}

	.computer-notes image {
		width: 23px;
		height: 20px;
		margin-right: 10px;
	}

	.computer-button {
		display: flex;
		flex-wrap: wrap;
		width: auto;
	}

	.computer-button-item {
		margin: 1.8% 0.5% 0.3%;
		width: 18.3%;
		padding: 2.4%;
		border: 1px solid #646464;
		border-radius: 10px;
		background-color: #ffe6f2;
		color: #00007f;
		text-align: center;
		font-weight: bold;
		font-size: 17px;
	}

	.computer-button-item image {
		display: flex;
		margin-left: 15px;
		width: 20px;
		height: 20px;
	}

	.cardtitle {
		font-size: 18px;
		font-weight: bold;
		border-bottom: 5rpx solid #ab0080;
		padding: 4px;
	}

	.datetitle {
		font-size: 20px;
		border-bottom: 1rpx solid #00007f;
	}

	.uni-input {
		font-size: 17px;
	}
</style>
