<template>
	<view>
		<!-- 收入支出栏 -->
		<view class="">
			<view class="IncomePay">
				<view v-for="item in Sumtitle" :class="item.Stitle==='收入'?'IncomePayTitle1':'IncomePayTitle2'" @tap="MoneyNavto()">
					<view class="IncomePayTitle-SumShow">
						{{item.Stitle === '收入' ? AccountSum.D : AccountSum.C}}
					</view>
					<view class="IncomePayTitle-text">
						{{item.Stitle}}
					</view>
				</view>
			</view>
		</view>
		<!-- 项目列表 -->
		<view class="IncomePaydetails-scroll" style="height: 100px;">
			<scroll-view scroll-y="true" style="height: 570%;margin-top: 20px;">
				<view class="IncomePaydetails" v-for="(item, key) in  sortedAccountdbget">
					<view class="IncomePaydetails-date">
						<view style="font-size: 20px;color: #ff6392;font-weight: bold;">{{key}}</view>
						<view style="font-size: 15px;margin-top: 4px;">
							收入:<text :style="{color:item.B>= 0?'#ff608a':'#74be88'}">{{item.B}}</text>
							支出:<text :style="{color:item.A>= 0?'#ff608a':'#74be88'}">{{item.A}}</text>
						</view>
					</view>
					<view class="IncomePaydetails-content" v-for="(dataItem, dataIndex) in item.data">
						<view class="IncomePaydetails-content-icon">
							<image :src="dataItem.DetailCategorylndex"></image>
							<view style="margin-top: 13%;">{{dataItem.DetailCategory}}</view>
						</view>
						<text style="font-weight: bold;text-align: right;margin-right: 15px;">
							<text :style="{color:dataItem.amountdb>=0?'#ff608a':'#74be88'}">{{dataItem.amountdb}}</text>
						</text>
					</view>
				</view>
			</scroll-view>
			<view class="AddAccountingImg" @tap="NavTo">
				<image src="../../static/add.png"></image>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				AccountSum: [],
				Sumtitle: [{
						"Stitle": "收入"
					},
					{
						"Stitle": "支出"
					}
				],
				Accountdbget: []
			}
		},
		onShow() {
			uni.showLoading({
				title: "加载中"
			})
			this.GetAccountNow()
		},
		computed: {
			sortedAccountdbget() {
				return Object.entries(this.Accountdbget)
					.sort((a, b) => new Date(b[0]) - new Date(a[0]))
					.reduce((obj, [key, value]) => {
						obj[key] = value;
						return obj;
					}, {});
			}
		},
		methods: {
			NavTo() {
				uni.navigateTo({
					url: "/pages/AddAccounting/AddAccounting"
				})
			},
			MoneyNavto() {
				uni.navigateTo({
					url: "/pages/Money/Money"
				})
			},
			GetAccountNow() {
				let that = this
				uni.showLoading({
					title: "加载中"
				})
				uniCloud.callFunction({
					name: "GetAccountList",
					data: {},
				}).then(res => {
					console.log(res)
					uni.hideLoading()
					that.Accountdbget = res.result.groupedData
					that.AccountSum = res.result.SumgroupedData
				}).catch(err => {
					console.log(err)
				})
			}
		}
	}
</script>

<style>
	page {
		background-color: #ffd3e6;
	}

	.AddAccountingImg image {
		width: 38px;
		height: 38px;
	}

	.AddAccountingImg {
		position: fixed;
		bottom: 80px;
		right: 35px;
	}

	.IncomePay {
		display: flex;
		justify-content: space-around;
	}

	.IncomePayTitle1,
	.IncomePayTitle2 {
		border: 0.5px solid #727b95;
		justify-content: space-around;
		width: 45%;
		height: 85px;
		display: flex;
		flex-direction: column;
		align-items: center;
		border-radius: 10px;
	}

	.IncomePayTitle1 {
		background-color: #e097ff;
		color: #ff608a;
	}

	.IncomePayTitle2 {
		background-color: #acfeff;
		color: #74be88;
	}

	.IncomePayTitle-SumShow {
		margin-top: 2%;
		height: 35px;
		font-size: 23px;
		font-weight: bold;
		margin-top: 5px;
	}

	.IncomePayTitle-text {
		color: #727b95;
		font-size: 18px;
	}

	.IncomePaydetails,
	.IncomePaydetails-content {
		display: flex;
		flex-wrap: wrap;

	}

	.IncomePaydetails-date {
		display: flex;
		justify-content: space-between;
		margin: 2%;
		width: 395px;
	}

	.IncomePaydetails-content {
		margin: 5px 23px 4px 23px;
		border: 2px solid #ff6392;
		width: 400%;
		font-size: 20px;
		border-radius: 10px;
		justify-content: space-between;
	}

	.IncomePaydetails-content-icon {
		display: flex;
		flex-wrap: wrap;
	}

	.IncomePaydetails-content-icon image {
		width: 45px;
		height: 45px;
		margin: 2px 4px 2px 4px;
	}

	.IncomePaydetails-content text {
		height: 30px;
		margin-top: 3.5%;
	}
</style>
