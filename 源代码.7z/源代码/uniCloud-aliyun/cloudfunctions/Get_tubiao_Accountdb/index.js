'use strict';

exports.main = async (event, context) => {
	const db = uniCloud.database(); // 初始化数据库连接
	const collection = db.collection("Accountdb"); // 定义数据库集合
	const $ = db.command.aggregate; // 简化聚合操作符的引用

	// 定义聚合查询以生成收支柱状图数据
	let res = await collection.aggregate()
		.group({
			"_id": '$Numdate',
			"IncomeTotal": $.sum($.multiply([$.abs($.subtract(['$grounp', 1])), '$amountdb'])),
			"ExpenseTotal": $.sum($.multiply(['$grounp', '$amountdb']))
		})
		.sort({
			"_id": -1
		})
		.end();

	let ChartList = {
		dateArray: [],
		IncomeArray: [],
		ExpenseArray: []
	};

	// 转换数据格式并计算最大支出
	let maxExpense = 0;
	res.data.forEach(item => {
		let tempDate = item._id.split("-")[1] + "." + item._id.split("-")[2];
		ChartList.dateArray.push(tempDate);
		ChartList.IncomeArray.push(item.IncomeTotal);
		ChartList.ExpenseArray.push(Math.abs(item.ExpenseTotal));
		if (item.ExpenseTotal > maxExpense) {
			maxExpense = item.ExpenseTotal;
		}
	});

	let maxNum = maxExpense + 200; // 定义收支最大数据界限

	// 获取支出分类统计
	let ExpenseCategoryList = await collection.aggregate()
		.match({
			"grounp": 1
		})
		.group({
			"_id": "$DetailCategory",
			"AllExpenseTotal": $.sum($.multiply(['$grounp', '$amountdb', -1])),
		})
		.end();

	let ExpenseRingList = ExpenseCategoryList.data.map(item => ({
		name: item._id,
		value: item.AllExpenseTotal,
		labelText: item._id + ":" + item.AllExpenseTotal + "元"
	}));

	// 获取收入分类统计
	let IncomeCategoryList = await collection.aggregate()
		.match({
			"grounp": 0
		})
		.group({
			"_id": "$DetailCategory",
			"AllIncomeTotal": $.sum($.multiply([$.abs($.subtract(['$grounp', 1])), '$amountdb'])),
		})
		.end();

	let IncomeRingList = IncomeCategoryList.data.map(item => ({
		name: item._id,
		value: item.AllIncomeTotal,
		labelText: item._id + ":" + item.AllIncomeTotal + "元"
	}));

	// 返回整合后的数据
	return {
		maxNum,
		ChartList,
		ExpenseRingList,
		IncomeRingList
	};
};
