'use strict';
exports.main = async (event, context) => {
	console.log('event : ', event)
	let db = uniCloud.database()
	return new Promise((resolve, reject) => {
		db.collection("todolist_db").where(
			event
		).get().then(res => {
			resolve(res)
		}).catch(err => {
			reject(err)
		})
	})
};
