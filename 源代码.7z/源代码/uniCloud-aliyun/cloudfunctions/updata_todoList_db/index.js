'use strict';
exports.main = async (event, context) => {
	console.log('event : ', event)
	let db = uniCloud.database()
	return new Promise((resolve,reject)=>{
		db.collection("todolist_db").doc(event.id).update(event.update).then(res=>{
			resolve(res)
		}).catch(err=>{
			reject(err)
		})
	})
	return event
};
