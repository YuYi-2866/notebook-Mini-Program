'use strict';
exports.main = async (event, context) => {
	console.log('event: ', event);
	try {
		const db = uniCloud.database();
		const collection = db.collection('Accountdb');
		const result = await collection.get();
		const data = result.data;
		const groupedData = {};
		let C = 0;
		let D = 0;
		data.forEach(item => {
			const numdate = item.Numdate;
			let A = 0;
			let B = 0;

			if (item.grounp === 1) {
				A += parseFloat(item.amountdb);
				C += parseFloat(item.amountdb);
			} else {
				B += parseFloat(item.amountdb);
				D += parseFloat(item.amountdb);
			}

			if (!groupedData[numdate]) {
				groupedData[numdate] = {
					data: [item],
					A,
					B
				};
			} else {
				groupedData[numdate].data.push(item);
				groupedData[numdate].A += A;
				groupedData[numdate].B += B;
			}
		});
		const SumgroupedData = {
			C,
			D
		};
		return {
			groupedData,
			SumgroupedData
		};
	} catch (err) {
		console.error(err);
		throw new Error('Failed to query database');
	}
};
