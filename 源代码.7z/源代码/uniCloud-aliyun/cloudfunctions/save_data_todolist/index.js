'use strict';
exports.main = async (event, context) => {
	console.log('event : ', event)
	let db = uniCloud.database()
	return new Promise((resolve, rejects) => {
		db.collection("todolist_db").add(event).then(res => {
			resolve(res)
		}).catch(err => {
			reject(err)
		})
	})
};
